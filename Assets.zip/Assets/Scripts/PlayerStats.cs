using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour
{
    public Text healthText;
    public Text goldText;

    public float maxHealth;
    public float currentHealth;
    public float gold;

    public List<int> items; //change this to a List<Items> later

    public float basicAttackDmg; //how much the basic attack deals
    public float abilityDamageMultiplier; //abilities will deal their base damage multiplied by this (ex: 100 * 1.2 = 120)
    public float critChance; //chance of getting a critical strike
    public float moveSpeed; //move speed, 1.0 is equal to the base move speed
    public float attackSpeed; //basic attack speed, 1.0 is equal to the base attack speed
    public float coolDownReduction; //ability cooldowns will be reduced by this number, base 1.0. ex: 10s * .9 = 9s cd

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        healthText.text = "HP: " + currentHealth + "/" + maxHealth; //change this later to update when the player takes damage
        goldText.text = "Gold: " + gold;

        if (Input.GetKeyDown(KeyCode.T))
            currentHealth--; //simple health testing
        if (Input.GetKeyDown(KeyCode.G))
            currentHealth++; //simple health testing

        if (currentHealth > maxHealth)
            currentHealth = maxHealth; //do not allow current to go over max
        if (currentHealth < 0)
            currentHealth = 0; //do not allow hp to go negative
    }
}
