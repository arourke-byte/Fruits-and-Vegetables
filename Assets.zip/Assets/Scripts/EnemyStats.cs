using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{
    public float maxHP;
    public float currentHP;

    int goldDropAmount;


    // Start is called before the first frame update
    void Start()
    {
        currentHP = maxHP; 
    }

    // Update is called once per frame
    void Update()
    {
        if (currentHP <= 0)
            Die();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

    }

    public void Die() 
    {
        Destroy(gameObject);
    }


}
