using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    Rigidbody2D rb;
    Animator anim;
    float horizontal;
    float vertical;

    public bool facingLeft;
    public bool facingRight;
    public float runSpeed;

    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        facingRight = true;
        facingLeft = false; 
    }

    void Update()
    {

        if (animatorIsPlaying("final_gambit"))
            runSpeed = 0;
        else
            runSpeed = 5;
        

        horizontal = Input.GetAxisRaw("Horizontal");
        vertical = Input.GetAxisRaw("Vertical");

        if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = true;
            facingRight = false;
            facingLeft = true;
        }
        
        if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) 
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = false;
            facingLeft = false;
            facingRight = true;
        }
            
    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontal * runSpeed, vertical * runSpeed);
    }

    private bool animatorIsPlaying(string animName) 
    {
        return anim.GetCurrentAnimatorStateInfo(0).IsName(animName);
    }

}

