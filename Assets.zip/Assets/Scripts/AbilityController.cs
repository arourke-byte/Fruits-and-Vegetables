using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbilityController : MonoBehaviour
{
    public GameObject grapeShot;
    public Transform bulletSpawnPoint;
    public float grapeShotSpeed;
    PlayerMovement pm;
    
    // Start is called before the first frame update
    void Start()
    {
        pm = gameObject.GetComponent<PlayerMovement>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) 
        {
            GrapeShot();
        }
    }

    void GrapeShot() 
    {

        
        if (pm.facingRight && !pm.facingLeft) 
        {
            GameObject bullet = Instantiate(grapeShot, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
            rb.AddForce(bulletSpawnPoint.right * grapeShotSpeed, ForceMode2D.Impulse);
        }
        if (pm.facingLeft && !pm.facingRight) 
        {
            GameObject bullet = Instantiate(grapeShot, bulletSpawnPoint.position, bulletSpawnPoint.rotation * Quaternion.Euler(0f, 180f, 0f));
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
            rb.AddForce(bulletSpawnPoint.right * grapeShotSpeed * -1, ForceMode2D.Impulse);
        }
            





    }


}
