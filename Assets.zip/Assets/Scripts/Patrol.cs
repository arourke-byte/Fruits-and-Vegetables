using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol : MonoBehaviour
{
    public float patrolSpeed; //speed for patrolling
    public float pursueSpeed; //speed for pursuing

    private float currentWaitTime; //time till next patrol
    public float baseWaitTime = 2; //time between patrol movements

    Vector2 movePoint; //point to move towards
    public float minX; //min x of map
    public float maxX; //max x of map
    public float minY; //min y of map
    public float maxY; //max y of map

    public Transform player;
    float distanceBetween; //distance between player and enemy

    bool isPatrolling; //patrol state
    bool isPursuing; //pursue state
    
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player").GetComponent<Transform>(); 
        currentWaitTime = baseWaitTime;
        movePoint = new Vector2(Random.Range(minX, maxX), Random.Range(minY, maxY));
    }

    // Update is called once per frame
    void Update()
    {
        if (Vector2.Distance(transform.position, player.position) <= 3) 
        {
            Purse();
        }
        else
            Search();

        if (Input.GetKeyDown(KeyCode.Z))
            Debug.Log("Is patrolling: " + isPatrolling + ". Is pursing: " + isPursuing); 
    }

    public void Search() 
    {
        isPatrolling = true;
        isPursuing = false;
        transform.position = Vector2.MoveTowards(transform.position, movePoint, patrolSpeed * Time.deltaTime);
        if (Vector2.Distance(transform.position, movePoint) <= 0.2f)
        {
            if (currentWaitTime <= 0)
            {
                movePoint = new Vector2(Random.Range(minX, maxX), Random.Range(minY, maxY));
                currentWaitTime = baseWaitTime;
            }
            else
                currentWaitTime -= Time.deltaTime;
        }
    }

    public void Purse() 
    {
        isPursuing = true;
        isPatrolling = false;
        transform.position = Vector2.MoveTowards(transform.position, player.position, pursueSpeed * Time.deltaTime);
    }


}
