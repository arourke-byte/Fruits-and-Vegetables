using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour
{
    EnemyStats stats;
    public float power; //damage of the grapeshot

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag.Equals("Enemy")) 
        { 
            stats = collision.gameObject.GetComponent<EnemyStats>();
            stats.currentHP -= power;
            Debug.Log("HP: " + stats.currentHP);
            Destroy(gameObject);
        }
    }
}
